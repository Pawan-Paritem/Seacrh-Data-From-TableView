//
//  ViewController.swift
//  TableViewTask
//
//  Created by Pawan iOS on 20/09/2022.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    @IBOutlet weak var tbView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var newData: Continents?
    var data: Continents?
    
    var AsiaCountriesSearchData     : [DataModel]?
    var EuropeCountriesSearchData   : [DataModel]?
    var NACountriesSearchData       : [DataModel]?
    var NSCountriesSearchData       : [DataModel]?
    var AfricaCountriesSearchData   : [DataModel]?
    var AntarticaCountriesSearchData: [DataModel]?
    var AusCountriesSearchData      : [DataModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tbView.delegate = self
        tbView.dataSource = self
        searchBar.delegate = self
        
        // addHeaderFooterView()
        data = loadJSONData(fileName: "languages")
        newData = data
        
        AsiaCountriesSearchData = newData?.Asia
        EuropeCountriesSearchData = newData?.Europe
        NACountriesSearchData  = newData?.NorthAmerica
        NSCountriesSearchData  = newData?.NorthAmerica
        AfricaCountriesSearchData  = newData?.Africa
        AntarticaCountriesSearchData  = newData?.Antarctica
        AusCountriesSearchData  = newData?.Australia
        
        tbView.reloadData()
    }
    
    func addHeaderFooterView() {
        
        let header = UIView(frame: CGRect(x: 0, y: 0, width: tbView.frame.width, height: 50))
        let footer = UIView(frame: CGRect(x: 0, y: 0, width: tbView.frame.width, height: 50))
        
        header.backgroundColor = .green
        footer.backgroundColor = .blue
        
        tbView.tableHeaderView = header
        tbView.tableFooterView = footer
        
        let HeaderLabel = UILabel(frame: CGRect(x: 180, y: 10, width: 400, height: 200))
        HeaderLabel.font = UIFont(name: "Helvetica", size: 22)
        HeaderLabel.textColor = UIColor.white
        HeaderLabel.text = "Header"
        HeaderLabel.sizeToFit()
        header.addSubview(HeaderLabel)
        
        let FooterLabel = UILabel(frame: CGRect(x: 180, y: 10, width: 400, height: 200))
        FooterLabel.font = UIFont(name: "Helvetica", size: 22)
        FooterLabel.textColor = UIColor.white
        FooterLabel.text = "Footer"
        FooterLabel.sizeToFit()
        footer.addSubview(FooterLabel)
    }
    
    func loadJSONData(fileName: String) -> Continents? {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode(Continents.self, from: data)
                return jsonData
            } catch {
                print("Error")
            }
        }
        return nil
    }
}

//Extension: - ViewController: UITableViewDataSource , UITableViewDelegate
extension ViewController: UITableViewDataSource , UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        //Top Left Right Corners
        let maskPathTop = UIBezierPath(roundedRect: cell.bounds, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 10.0, height: 10.0))
        
        let shapeLayerTop = CAShapeLayer()
        shapeLayerTop.frame = cell.bounds
        shapeLayerTop.path = maskPathTop.cgPath
        
        //Bottom Left Right Corners
        let maskPathBottom = UIBezierPath(roundedRect: cell.bounds, byRoundingCorners: [.bottomLeft, .bottomRight], cornerRadii: CGSize(width: 10.0, height: 10.0))
        
        let shapeLayerBottom = CAShapeLayer()
        shapeLayerBottom.frame = cell.bounds
        shapeLayerBottom.path = maskPathBottom.cgPath
        
        //All Corners
        
        if (indexPath.row == 0)
        {
            cell.layer.mask = shapeLayerTop
        }
        else if (indexPath.row == tableView.numberOfRows(inSection: indexPath.section)-1)
        {
            cell.layer.mask = shapeLayerBottom
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 25.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView()
        
        let sectionLabel = UILabel(frame: CGRect(x: 0, y: 0, width:tbView.bounds.size.width, height: tbView.bounds.size.height))
        sectionLabel.font = UIFont(name: "American Typewriter", size: 18)
        sectionLabel.textColor = UIColor.gray
        
        if section == 0 {
            sectionLabel.text = "Asia"
        }  else if section == 1 {
            sectionLabel.text = "Europe"
        } else if section == 2 {
            sectionLabel.text = "North America"
        } else if section == 3 {
            sectionLabel.text = "South America"
        } else if section == 4 {
            sectionLabel.text = "Africa"
        } else if section == 5{
            sectionLabel.text = "Antarctica"
        } else {
            sectionLabel.text = "Australia"
        }
        
        sectionLabel.sizeToFit()
        view.backgroundColor = UIColor.systemGray6
        view.addSubview(sectionLabel)
        
        return view
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return (AsiaCountriesSearchData?.count) ?? 0
        } else if section == 1 {
            return (EuropeCountriesSearchData?.count) ?? 0
        } else if section == 2 {
            return (NACountriesSearchData?.count) ?? 0
        } else if section == 3 {
            return (NSCountriesSearchData?.count) ?? 0
        } else if section == 4 {
            return (AfricaCountriesSearchData?.count) ?? 0
        } else if section == 5 {
            return (AntarticaCountriesSearchData?.count) ?? 0
        } else {
            return (AusCountriesSearchData?.count) ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if newData == nil { return UITableViewCell() }
        
        if indexPath.section == 0 {
            let cell = TbViewCell.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = AsiaCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
            
        } else if indexPath.section == 1 {
            let cell = TbViewCell2.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = EuropeCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
            
        } else if indexPath.section == 2 {
            let cell = TbViewCell3.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = NACountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
            
        } else if indexPath.section == 3 {
            let cell = TBViewCell4.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = NSCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
            
        } else if indexPath.section == 4 {
            let cell = TBViewCell5.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = AfricaCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
            
        } else if indexPath.section == 5 {
            let cell = TbViewCell6.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = AntarticaCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
        } else {
            let cell = TBViewCell7.registerTableViewCell(tableView: tableView, indexPath: indexPath)
            cell.lblName.text = AusCountriesSearchData![indexPath.row].language
            cell.backgroundColor = .white
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}

//Extension: -ViewController: UISearchBarDelegate
extension ViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText != "" {
            AsiaCountriesSearchData = newData!.Asia.filter({ dataModel in return dataModel.language.contains(searchText) })
            EuropeCountriesSearchData = newData!.Europe.filter({ dataModel2 in dataModel2.language.contains(searchText)})
            NACountriesSearchData = newData!.NorthAmerica.filter({ dataModel2 in dataModel2.language.contains(searchText)})
            NSCountriesSearchData = newData!.SouthAmerica.filter({ dataModel2 in dataModel2.language.contains(searchText)})
            AfricaCountriesSearchData = newData!.Africa.filter({ dataModel2 in dataModel2.language.contains(searchText)})
            AntarticaCountriesSearchData = newData!.Antarctica.filter({ dataModel2 in dataModel2.language.contains(searchText)})
            AusCountriesSearchData = newData!.Australia.filter({ dataModel2 in dataModel2.language.contains(searchText)})

            tbView.reloadData()
          
        } else {
            AsiaCountriesSearchData = newData?.Asia
            EuropeCountriesSearchData = newData?.Europe
            NACountriesSearchData = newData?.NorthAmerica
            NSCountriesSearchData = newData?.NorthAmerica
            AfricaCountriesSearchData = newData?.Africa
            AntarticaCountriesSearchData = newData?.Antarctica
            AusCountriesSearchData = newData?.Australia
            
            tbView.reloadData()
        }
    }
}
