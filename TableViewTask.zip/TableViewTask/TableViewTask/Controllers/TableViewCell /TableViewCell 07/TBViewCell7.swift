//
//  TBViewCell7.swift
//  TableViewTask
//
//  Created by Pawan iOS on 21/09/2022.
//

import UIKit

class TBViewCell7: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TBViewCell7 {
        tableView.register(UINib(nibName: "TBViewCell7", bundle: nil), forCellReuseIdentifier: "TBViewCell7")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TBViewCell7", for: indexPath) as! TBViewCell7
        
        return cell
    }
    
}
