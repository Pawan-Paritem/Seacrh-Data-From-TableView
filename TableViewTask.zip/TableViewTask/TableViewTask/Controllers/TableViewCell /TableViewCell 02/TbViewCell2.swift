//
//  TbViewCell2.swift
//  TableViewTask
//
//  Created by Pawan iOS on 20/09/2022.
//

import UIKit

class TbViewCell2: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TbViewCell2 {
        tableView.register(UINib(nibName: "TbViewCell2", bundle: nil), forCellReuseIdentifier: "TbViewCell2")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbViewCell2", for: indexPath) as! TbViewCell2
        
        return cell
    }
    
}
