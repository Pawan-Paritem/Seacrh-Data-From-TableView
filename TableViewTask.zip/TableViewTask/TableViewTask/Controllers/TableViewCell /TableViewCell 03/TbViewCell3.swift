//
//  TbViewCell3.swift
//  TableViewTask
//
//  Created by Pawan iOS on 20/09/2022.
//

import UIKit

class TbViewCell3: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TbViewCell3 {
        tableView.register(UINib(nibName: "TbViewCell3", bundle: nil), forCellReuseIdentifier: "TbViewCell3")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbViewCell3", for: indexPath) as! TbViewCell3
        
        return cell
    }
    
}
