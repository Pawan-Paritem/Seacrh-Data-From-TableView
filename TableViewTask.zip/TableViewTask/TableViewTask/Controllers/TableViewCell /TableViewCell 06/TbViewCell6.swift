//
//  TbViewCell6.swift
//  TableViewTask
//
//  Created by Pawan iOS on 21/09/2022.
//

import UIKit

class TbViewCell6: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TbViewCell6 {
        tableView.register(UINib(nibName: "TbViewCell6", bundle: nil), forCellReuseIdentifier: "TbViewCell6")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbViewCell6", for: indexPath) as! TbViewCell6
        
        return cell
    }
    
}
