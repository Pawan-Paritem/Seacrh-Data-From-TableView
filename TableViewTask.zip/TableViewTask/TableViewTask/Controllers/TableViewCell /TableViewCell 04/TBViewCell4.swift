//
//  TBViewCell4.swift
//  TableViewTask
//
//  Created by Pawan iOS on 21/09/2022.
//

import UIKit

class TBViewCell4: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TBViewCell4 {
        tableView.register(UINib(nibName: "TBViewCell4", bundle: nil), forCellReuseIdentifier: "TBViewCell4")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TBViewCell4", for: indexPath) as! TBViewCell4
        
        return cell
    }
    
}
