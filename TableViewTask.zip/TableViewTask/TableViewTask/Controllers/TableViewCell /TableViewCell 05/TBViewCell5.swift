//
//  TBViewCell5.swift
//  TableViewTask
//
//  Created by Pawan iOS on 21/09/2022.
//

import UIKit

class TBViewCell5: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
       
    }
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TBViewCell5 {
        tableView.register(UINib(nibName: "TBViewCell5", bundle: nil), forCellReuseIdentifier: "TBViewCell5")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TBViewCell5", for: indexPath) as! TBViewCell5
        
        return cell
    }
    
}
