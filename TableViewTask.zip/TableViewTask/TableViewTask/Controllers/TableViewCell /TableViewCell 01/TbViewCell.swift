//
//  TbViewCell.swift
//  TableViewTask
//
//  Created by Pawan iOS on 20/09/2022.
//

import UIKit

class TbViewCell: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    class func registerTableViewCell( tableView: UITableView, indexPath: IndexPath) -> TbViewCell {
        tableView.register(UINib(nibName: "TbViewCell", bundle: nil), forCellReuseIdentifier: "TbViewCell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "TbViewCell", for: indexPath) as! TbViewCell
        
        return cell
    }
}
