//
//  DataModel.swift
//  TableViewTask
//
//  Created by Pawan iOS on 20/09/2022.
//

import Foundation
import UIKit

struct Continents:Codable {
  //  var data:[DataModel]
    var Asia        :[DataModel]
    var Europe      : [DataModel]
    var NorthAmerica: [DataModel]
    var SouthAmerica: [DataModel]
    var Africa      : [DataModel]
    var Antarctica  : [DataModel]
    var Australia   : [DataModel]
    
}

struct DataModel: Codable {
    var language: String
}
